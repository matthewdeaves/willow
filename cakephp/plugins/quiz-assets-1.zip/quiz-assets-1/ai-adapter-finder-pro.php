<?php
/**
 * Plugin Name: AI Adapter Finder Pro
 * Plugin URI: https://your-domain.com/ai-adapter-finder
 * Description: AI-powered quiz system to find the perfect adapter, charger, or cord for any device with WordPress, Formidable Forms, and Elementor integration
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 * Text Domain: ai-adapter-finder
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AI_ADAPTER_FINDER_VERSION', '1.0.0');
define('AI_ADAPTER_FINDER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AI_ADAPTER_FINDER_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('AI_ADAPTER_FINDER_PLUGIN_FILE', __FILE__);

// Main plugin class
class AI_Adapter_Finder_Pro {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_action('wp_ajax_ai_adapter_quiz_submit', array($this, 'handle_quiz_submission'));
        add_action('wp_ajax_nopriv_ai_adapter_quiz_submit', array($this, 'handle_quiz_submission'));
        add_action('wp_ajax_ai_adapter_get_recommendations', array($this, 'get_ai_recommendations'));
        add_action('wp_ajax_nopriv_ai_adapter_get_recommendations', array($this, 'get_ai_recommendations'));

        // Admin hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));

        // Shortcode registration
        add_shortcode('ai_adapter_quiz', array($this, 'render_quiz_shortcode'));

        // Plugin activation/deactivation
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        // Load includes
        $this->load_includes();
    }

    public function init() {
        // Load text domain for internationalization
        load_plugin_textdomain('ai-adapter-finder', false, dirname(plugin_basename(__FILE__)) . '/languages');

        // Create database tables if needed
        $this->create_database_tables();
    }

    public function load_includes() {
        require_once AI_ADAPTER_FINDER_PLUGIN_PATH . 'includes/class-ai-matching-engine.php';
        require_once AI_ADAPTER_FINDER_PLUGIN_PATH . 'includes/class-formidable-integration.php';
        require_once AI_ADAPTER_FINDER_PLUGIN_PATH . 'includes/class-elementor-integration.php';
        require_once AI_ADAPTER_FINDER_PLUGIN_PATH . 'includes/class-quiz-renderer.php';
        require_once AI_ADAPTER_FINDER_PLUGIN_PATH . 'includes/class-admin-interface.php';
    }

    public function enqueue_scripts() {
        wp_enqueue_script(
            'ai-adapter-finder-js',
            AI_ADAPTER_FINDER_PLUGIN_URL . 'assets/js/quiz-frontend.js',
            array('jquery'),
            AI_ADAPTER_FINDER_VERSION,
            true
        );

        wp_enqueue_style(
            'ai-adapter-finder-css',
            AI_ADAPTER_FINDER_PLUGIN_URL . 'assets/css/quiz-frontend.css',
            array(),
            AI_ADAPTER_FINDER_VERSION
        );

        // Localize script for AJAX
        wp_localize_script('ai-adapter-finder-js', 'aiAdapterAjax', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_adapter_nonce'),
            'loading_text' => __('Analyzing your needs with AI...', 'ai-adapter-finder'),
            'error_text' => __('Sorry, something went wrong. Please try again.', 'ai-adapter-finder')
        ));
    }

    public function admin_enqueue_scripts($hook) {
        if (strpos($hook, 'ai-adapter-finder') !== false) {
            wp_enqueue_script(
                'ai-adapter-finder-admin-js',
                AI_ADAPTER_FINDER_PLUGIN_URL . 'assets/js/admin.js',
                array('jquery'),
                AI_ADAPTER_FINDER_VERSION,
                true
            );

            wp_enqueue_style(
                'ai-adapter-finder-admin-css',
                AI_ADAPTER_FINDER_PLUGIN_URL . 'assets/css/admin.css',
                array(),
                AI_ADAPTER_FINDER_VERSION
            );
        }
    }

    public function add_admin_menu() {
        add_menu_page(
            __('AI Adapter Finder', 'ai-adapter-finder'),
            __('Adapter Finder', 'ai-adapter-finder'),
            'manage_options',
            'ai-adapter-finder',
            array($this, 'admin_page'),
            'dashicons-search',
            30
        );

        add_submenu_page(
            'ai-adapter-finder',
            __('Quiz Settings', 'ai-adapter-finder'),
            __('Quiz Settings', 'ai-adapter-finder'),
            'manage_options',
            'ai-adapter-finder-settings',
            array($this, 'settings_page')
        );

        add_submenu_page(
            'ai-adapter-finder',
            __('Product Database', 'ai-adapter-finder'),
            __('Products', 'ai-adapter-finder'),
            'manage_options',
            'ai-adapter-finder-products',
            array($this, 'products_page')
        );
    }

    public function render_quiz_shortcode($atts) {
        $atts = shortcode_atts(array(
            'theme' => 'default',
            'show_progress' => 'true',
            'ai_powered' => 'true',
            'max_results' => 5,
            'style' => 'modern'
        ), $atts);

        ob_start();
        include AI_ADAPTER_FINDER_PLUGIN_PATH . 'templates/quiz-frontend.php';
        return ob_get_clean();
    }

    public function handle_quiz_submission() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'ai_adapter_nonce')) {
            wp_die(__('Security check failed', 'ai-adapter-finder'));
        }

        $quiz_data = $_POST['quiz_data'];

        // Initialize AI matching engine
        $ai_engine = new AI_Matching_Engine();
        $recommendations = $ai_engine->find_matches($quiz_data);

        // Log the quiz submission for analytics
        $this->log_quiz_submission($quiz_data, $recommendations);

        wp_send_json_success(array(
            'recommendations' => $recommendations,
            'confidence_scores' => $ai_engine->get_confidence_scores(),
            'ai_explanation' => $ai_engine->get_explanation()
        ));
    }

    public function get_ai_recommendations() {
        // Handle real-time AI recommendations as user fills the quiz
        if (!wp_verify_nonce($_POST['nonce'], 'ai_adapter_nonce')) {
            wp_die(__('Security check failed', 'ai-adapter-finder'));
        }

        $partial_data = $_POST['partial_data'];
        $ai_engine = new AI_Matching_Engine();
        $suggestions = $ai_engine->get_live_suggestions($partial_data);

        wp_send_json_success($suggestions);
    }

    private function create_database_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        // Products table
        $products_table = $wpdb->prefix . 'ai_adapter_products';
        $sql_products = "CREATE TABLE $products_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            manufacturer varchar(100),
            port_type varchar(50),
            form_factor varchar(50),
            device_gender varchar(20),
            device_cat varchar(100),
            device_compatibility text,
            price decimal(10,2),
            rating decimal(3,2),
            certified tinyint(1) DEFAULT 0,
            status varchar(20) DEFAULT 'pending',
            rel_score decimal(5,4),
            views int DEFAULT 0,
            created datetime DEFAULT CURRENT_TIMESTAMP,
            updated datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY manufacturer (manufacturer),
            KEY port_type (port_type),
            KEY device_cat (device_cat),
            KEY price (price),
            KEY rating (rating),
            KEY status (status)
        ) $charset_collate;";

        // Quiz submissions table for analytics
        $submissions_table = $wpdb->prefix . 'ai_adapter_quiz_submissions';
        $sql_submissions = "CREATE TABLE $submissions_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20),
            session_id varchar(50),
            quiz_data longtext,
            recommendations longtext,
            selected_product_id mediumint(9),
            confidence_score decimal(5,4),
            submission_time datetime DEFAULT CURRENT_TIMESTAMP,
            ip_address varchar(45),
            user_agent text,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY submission_time (submission_time),
            KEY selected_product_id (selected_product_id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_products);
        dbDelta($sql_submissions);
    }

    private function log_quiz_submission($quiz_data, $recommendations) {
        global $wpdb;

        $table = $wpdb->prefix . 'ai_adapter_quiz_submissions';

        $wpdb->insert(
            $table,
            array(
                'user_id' => get_current_user_id(),
                'session_id' => session_id(),
                'quiz_data' => json_encode($quiz_data),
                'recommendations' => json_encode($recommendations),
                'ip_address' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT']
            )
        );
    }

    public function admin_page() {
        include AI_ADAPTER_FINDER_PLUGIN_PATH . 'admin/dashboard.php';
    }

    public function settings_page() {
        include AI_ADAPTER_FINDER_PLUGIN_PATH . 'admin/settings.php';
    }

    public function products_page() {
        include AI_ADAPTER_FINDER_PLUGIN_PATH . 'admin/products.php';
    }

    public function activate() {
        // Flush rewrite rules
        flush_rewrite_rules();

        // Set default options
        add_option('ai_adapter_finder_version', AI_ADAPTER_FINDER_VERSION);
        add_option('ai_adapter_finder_settings', array(
            'ai_enabled' => true,
            'confidence_threshold' => 0.6,
            'max_results' => 5,
            'enable_analytics' => true,
            'enable_formidable_integration' => true,
            'enable_elementor_integration' => true
        ));
    }

    public function deactivate() {
        // Clean up if needed
        flush_rewrite_rules();
    }
}

// Initialize the plugin
AI_Adapter_Finder_Pro::get_instance();
?>