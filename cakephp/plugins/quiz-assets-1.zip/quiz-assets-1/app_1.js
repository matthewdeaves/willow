// Application State
const AppState = {
    currentPage: 'welcome-page',
    quizType: null,
    akinatorData: {
        currentQuestion: 0,
        answers: [],
        confidence: 0,
        questionPath: []
    },
    comprehensiveData: {
        currentStep: 1,
        answers: {},
        totalSteps: 6
    },
    products: [],
    filteredProducts: []
};

// Quiz Data
const akinatorQuestions = [
    {
        id: "q1",
        question: "Is your device something you can hold in one hand?",
        yes_next: "q2_handheld",
        no_next: "q2_large"
    },
    {
        id: "q2_handheld",
        question: "Does your device make phone calls?",
        yes_next: "q3_phone",
        no_next: "q3_non_phone"
    },
    {
        id: "q2_large", 
        question: "Is it primarily used for computing or work?",
        yes_next: "q3_computer",
        no_next: "q3_entertainment"
    },
    {
        id: "q3_phone",
        question: "Does it have a round home button on the front?",
        yes_next: "result_old_iphone",
        no_next: "q4_modern_phone"
    },
    {
        id: "q4_modern_phone",
        question: "Does your phone charge with USB-C?",
        yes_next: "result_android_usbc",
        no_next: "result_iphone_lightning"
    },
    {
        id: "q3_computer",
        question: "Is it made by Apple?",
        yes_next: "q4_mac",
        no_next: "result_pc_laptop"
    },
    {
        id: "q4_mac",
        question: "Does it charge with a magnetic connector?",
        yes_next: "result_macbook_magsafe", 
        no_next: "result_macbook_usbc"
    },
    {
        id: "q3_non_phone",
        question: "Do you put it in your ears?",
        yes_next: "q4_earbuds",
        no_next: "result_tablet"
    },
    {
        id: "q4_earbuds",
        question: "Do they come in a small white case?",
        yes_next: "result_airpods",
        no_next: "result_other_earbuds"
    },
    {
        id: "q3_entertainment",
        question: "Is it used for gaming?",
        yes_next: "result_gaming_console",
        no_next: "result_tv_device"
    }
];

const products = [
    {
        id: "mac_charger_white",
        title: "MacBook Air USB-C Charger - 30W",
        manufacturer: "Apple",
        port_type: "usb-c",
        price: 59.00,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=300&h=200&fit=crop",
        compatibility: ["MacBook Air", "iPad Pro"],
        features: ["Fast Charging", "Compact Design", "Official Apple"],
        tags: ["macbook", "usbc", "apple", "laptop"]
    },
    {
        id: "iphone_lightning",
        title: "iPhone Lightning Cable + 20W Adapter",
        manufacturer: "Apple", 
        port_type: "lightning",
        price: 39.00,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=300&h=200&fit=crop",
        compatibility: ["iPhone 6-14", "iPad with Lightning"],
        features: ["MFi Certified", "Fast Charging", "Durable"],
        tags: ["iphone", "lightning", "apple", "phone"]
    },
    {
        id: "android_usbc",
        title: "Universal USB-C Fast Charger - 45W",
        manufacturer: "Samsung",
        port_type: "usb-c", 
        price: 29.00,
        rating: 4.4,
        image: "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=300&h=200&fit=crop",
        compatibility: ["Samsung Galaxy", "Google Pixel", "Most Android phones"],
        features: ["Universal Compatibility", "Fast Charging", "Compact"],
        tags: ["android", "usbc", "samsung", "phone"]
    },
    {
        id: "gaming_laptop",
        title: "Gaming Laptop Power Adapter - 180W",
        manufacturer: "ASUS",
        port_type: "barrel",
        price: 89.00,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1593642702821-c8da6771f0c6?w=300&h=200&fit=crop",
        compatibility: ["ASUS Gaming Laptops", "High-power devices"],
        features: ["High Power Output", "Gaming Optimized", "Robust Build"],
        tags: ["gaming", "laptop", "asus", "high-power"]
    },
    {
        id: "airpods_case",
        title: "AirPods Pro USB-C Charging Case",
        manufacturer: "Apple",
        port_type: "usb-c",
        price: 79.00,  
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=300&h=200&fit=crop",
        compatibility: ["AirPods Pro 2nd Gen", "AirPods 3rd Gen"],
        features: ["Wireless Charging", "USB-C", "Premium Design"],
        tags: ["airpods", "usbc", "apple", "earbuds"]
    },
    {
        id: "multi_port_hub",
        title: "6-Port USB Charging Hub - 60W",
        manufacturer: "Anker",
        port_type: "multiple",
        price: 45.00,
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=300&h=200&fit=crop", 
        compatibility: ["Universal", "Multiple devices"],
        features: ["6 Ports", "Smart Charging", "Compact Design"],
        tags: ["multiport", "universal", "anker", "hub"]
    }
];

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    console.log('App initializing...');
    AppState.products = products;
    AppState.filteredProducts = products;
    initializeEventListeners();
    showPage('welcome-page');
});

// Page Management
function showPage(pageId) {
    console.log('Showing page:', pageId);
    
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    // Show target page
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.add('active');
        AppState.currentPage = pageId;
        console.log('Page shown successfully:', pageId);
    } else {
        console.error('Page not found:', pageId);
    }
}

// Event Listeners
function initializeEventListeners() {
    console.log('Initializing event listeners...');
    
    // Welcome page quiz selection
    document.querySelectorAll('.quiz-option').forEach(option => {
        option.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Quiz option clicked:', this.dataset.quizType);
            const quizType = this.dataset.quizType;
            startQuiz(quizType);
        });
    });

    // Admin database access
    const adminBtn = document.getElementById('admin-btn');
    if (adminBtn) {
        adminBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Admin button clicked');
            showProductDatabase();
        });
    }

    // Akinator quiz buttons
    const yesBtn = document.getElementById('yes-btn');
    const noBtn = document.getElementById('no-btn');
    
    if (yesBtn) {
        yesBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Yes button clicked');
            answerAkinatorQuestion(true);
        });
    }
    
    if (noBtn) {
        noBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('No button clicked');
            answerAkinatorQuestion(false);
        });
    }

    // Back buttons
    const akinatorBack = document.getElementById('akinator-back');
    if (akinatorBack) {
        akinatorBack.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Akinator back button clicked');
            showPage('welcome-page');
        });
    }

    const comprehensiveBack = document.getElementById('comprehensive-back');
    if (comprehensiveBack) {
        comprehensiveBack.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Comprehensive back button clicked');
            showPage('welcome-page');
        });
    }

    const databaseBack = document.getElementById('database-back');
    if (databaseBack) {
        databaseBack.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Database back button clicked');
            showPage('welcome-page');
        });
    }

    // Comprehensive quiz navigation
    const nextBtn = document.getElementById('next-btn');
    const prevBtn = document.getElementById('prev-btn');
    const submitBtn = document.getElementById('submit-btn');
    
    if (nextBtn) {
        nextBtn.addEventListener('click', function(e) {
            e.preventDefault();
            nextComprehensiveStep();
        });
    }
    
    if (prevBtn) {
        prevBtn.addEventListener('click', function(e) {
            e.preventDefault();
            prevComprehensiveStep();
        });
    }
    
    if (submitBtn) {
        submitBtn.addEventListener('click', function(e) {
            e.preventDefault();
            submitComprehensiveQuiz(e);
        });
    }

    // Results page
    const retakeBtn = document.getElementById('retake-quiz');
    const newSearchBtn = document.getElementById('new-search');
    
    if (retakeBtn) {
        retakeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showPage('welcome-page');
        });
    }
    
    if (newSearchBtn) {
        newSearchBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showPage('welcome-page');
        });
    }

    // Database page
    const productSearch = document.getElementById('product-search');
    const filterManufacturer = document.getElementById('filter-manufacturer');
    
    if (productSearch) {
        productSearch.addEventListener('input', filterProducts);
    }
    
    if (filterManufacturer) {
        filterManufacturer.addEventListener('change', filterProducts);
    }

    // Form input handlers
    setupComprehensiveFormHandlers();
    
    console.log('Event listeners initialized successfully');
}

function startQuiz(quizType) {
    console.log('Starting quiz:', quizType);
    AppState.quizType = quizType;
    
    if (quizType === 'akinator') {
        resetAkinatorQuiz();
        showPage('akinator-page');
        displayAkinatorQuestion();
    } else if (quizType === 'comprehensive') {
        resetComprehensiveQuiz();
        showPage('comprehensive-page');
    }
}

// Akinator Quiz Logic
function resetAkinatorQuiz() {
    console.log('Resetting Akinator quiz');
    AppState.akinatorData = {
        currentQuestion: 0,
        answers: [],
        confidence: 15,
        questionPath: ['q1']
    };
    updateAkinatorUI();
    updateConfidenceMeter();
}

function displayAkinatorQuestion() {
    const currentQuestionId = AppState.akinatorData.questionPath[AppState.akinatorData.currentQuestion];
    console.log('Displaying question:', currentQuestionId);
    
    const questionData = akinatorQuestions.find(q => q.id === currentQuestionId);
    
    if (questionData) {
        showThinkingAnimation();
        
        setTimeout(() => {
            hideThinkingAnimation();
            const questionElement = document.getElementById('akinator-question');
            if (questionElement) {
                questionElement.textContent = questionData.question;
            }
            updateAkinatorUI();
        }, 1000);
    } else {
        // Handle result
        console.log('Showing result for:', currentQuestionId);
        showAkinatorResult(currentQuestionId);
    }
}

function answerAkinatorQuestion(answer) {
    console.log('Answering question with:', answer);
    
    const currentQuestionId = AppState.akinatorData.questionPath[AppState.akinatorData.currentQuestion];
    const questionData = akinatorQuestions.find(q => q.id === currentQuestionId);
    
    if (!questionData) {
        console.error('Question data not found for:', currentQuestionId);
        return;
    }
    
    AppState.akinatorData.answers.push(answer);
    AppState.akinatorData.confidence = Math.min(95, AppState.akinatorData.confidence + 15);
    
    const nextQuestionId = answer ? questionData.yes_next : questionData.no_next;
    AppState.akinatorData.questionPath.push(nextQuestionId);
    AppState.akinatorData.currentQuestion++;
    
    console.log('Next question ID:', nextQuestionId);
    console.log('Current question index:', AppState.akinatorData.currentQuestion);
    
    updateConfidenceMeter();
    
    if (nextQuestionId.startsWith('result_')) {
        setTimeout(() => {
            showAkinatorResult(nextQuestionId);
        }, 500);
    } else {
        displayAkinatorQuestion();
    }
}

function showAkinatorResult(resultId) {
    console.log('Showing Akinator result:', resultId);
    const resultData = getAkinatorResultData(resultId);
    showLoadingPage(() => {
        displayResults([resultData]);
    });
}

function getAkinatorResultData(resultId) {
    const resultMap = {
        'result_old_iphone': { id: 'iphone_lightning', confidence: 95 },
        'result_android_usbc': { id: 'android_usbc', confidence: 92 },
        'result_iphone_lightning': { id: 'iphone_lightning', confidence: 88 },
        'result_pc_laptop': { id: 'gaming_laptop', confidence: 85 },
        'result_macbook_magsafe': { id: 'mac_charger_white', confidence: 93 },
        'result_macbook_usbc': { id: 'mac_charger_white', confidence: 90 },
        'result_tablet': { id: 'mac_charger_white', confidence: 80 },
        'result_airpods': { id: 'airpods_case', confidence: 96 },
        'result_other_earbuds': { id: 'android_usbc', confidence: 75 },
        'result_gaming_console': { id: 'gaming_laptop', confidence: 70 },
        'result_tv_device': { id: 'multi_port_hub', confidence: 65 }
    };
    
    const result = resultMap[resultId] || { id: 'multi_port_hub', confidence: 60 };
    const product = products.find(p => p.id === result.id);
    
    return {
        ...product,
        confidence: result.confidence,
        explanation: `Based on your answers, this appears to be the best match for your device.`
    };
}

function showThinkingAnimation() {
    const thinkingElement = document.getElementById('akinator-thinking');
    const questionElement = document.getElementById('akinator-question');
    
    if (thinkingElement) {
        thinkingElement.classList.remove('hidden');
    }
    if (questionElement) {
        questionElement.style.opacity = '0.5';
    }
}

function hideThinkingAnimation() {
    const thinkingElement = document.getElementById('akinator-thinking');
    const questionElement = document.getElementById('akinator-question');
    
    if (thinkingElement) {
        thinkingElement.classList.add('hidden');
    }
    if (questionElement) {
        questionElement.style.opacity = '1';
    }
}

function updateAkinatorUI() {
    const currentNum = AppState.akinatorData.currentQuestion + 1;
    const currentQuestionElement = document.getElementById('current-question');
    const totalQuestionsElement = document.getElementById('total-questions');
    
    if (currentQuestionElement) {
        currentQuestionElement.textContent = currentNum;
    }
    if (totalQuestionsElement) {
        totalQuestionsElement.textContent = '10';
    }
}

function updateConfidenceMeter() {
    const confidence = AppState.akinatorData.confidence;
    const confidenceFill = document.getElementById('confidence-fill');
    const confidencePercent = document.querySelector('.confidence-percent');
    
    if (confidenceFill) {
        confidenceFill.style.width = `${confidence}%`;
    }
    if (confidencePercent) {
        confidencePercent.textContent = `${confidence}%`;
    }
}

// Comprehensive Quiz Logic
function resetComprehensiveQuiz() {
    AppState.comprehensiveData = {
        currentStep: 1,
        answers: {},
        totalSteps: 6
    };
    updateComprehensiveUI();
}

function setupComprehensiveFormHandlers() {
    // Budget range sliders
    const budgetMin = document.getElementById('budget-min');
    const budgetMax = document.getElementById('budget-max');
    
    function updateBudgetDisplay() {
        const minVal = parseInt(budgetMin.value);
        const maxVal = parseInt(budgetMax.value);
        
        if (minVal >= maxVal) {
            budgetMin.value = maxVal - 10;
        }
        
        document.getElementById('budget-min-value').textContent = budgetMin.value;
        document.getElementById('budget-max-value').textContent = budgetMax.value;
        
        AppState.comprehensiveData.answers.budget = [parseInt(budgetMin.value), parseInt(budgetMax.value)];
    }
    
    if (budgetMin && budgetMax) {
        budgetMin.addEventListener('input', updateBudgetDisplay);
        budgetMax.addEventListener('input', updateBudgetDisplay);
        updateBudgetDisplay();
    }
    
    // Radio and checkbox handlers
    document.querySelectorAll('input[type="radio"], input[type="checkbox"]').forEach(input => {
        input.addEventListener('change', function() {
            const name = this.name;
            
            if (this.type === 'radio') {
                AppState.comprehensiveData.answers[name] = this.value;
            } else if (this.type === 'checkbox') {
                if (!AppState.comprehensiveData.answers[name]) {
                    AppState.comprehensiveData.answers[name] = [];
                }
                
                if (this.checked) {
                    AppState.comprehensiveData.answers[name].push(this.value);
                } else {
                    const index = AppState.comprehensiveData.answers[name].indexOf(this.value);
                    if (index > -1) {
                        AppState.comprehensiveData.answers[name].splice(index, 1);
                    }
                }
            }
            
            updateComprehensiveNavigation();
        });
    });
}

function nextComprehensiveStep() {
    if (AppState.comprehensiveData.currentStep < AppState.comprehensiveData.totalSteps) {
        AppState.comprehensiveData.currentStep++;
        updateComprehensiveUI();
    }
}

function prevComprehensiveStep() {
    if (AppState.comprehensiveData.currentStep > 1) {
        AppState.comprehensiveData.currentStep--;
        updateComprehensiveUI();
    }
}

function updateComprehensiveUI() {
    const currentStep = AppState.comprehensiveData.currentStep;
    const totalSteps = AppState.comprehensiveData.totalSteps;
    
    // Update progress bar
    const progressPercent = (currentStep / totalSteps) * 100;
    const progressFill = document.getElementById('progress-fill');
    if (progressFill) {
        progressFill.style.width = `${progressPercent}%`;
    }
    
    // Update step indicators
    document.querySelectorAll('.step').forEach((step, index) => {
        step.classList.remove('active', 'completed');
        if (index + 1 === currentStep) {
            step.classList.add('active');
        } else if (index + 1 < currentStep) {
            step.classList.add('completed');
        }
    });
    
    // Show current form step
    document.querySelectorAll('.form-step').forEach(step => {
        step.classList.remove('active');
    });
    const currentStepElement = document.querySelector(`[data-step="${currentStep}"]`);
    if (currentStepElement) {
        currentStepElement.classList.add('active');
    }
    
    updateComprehensiveNavigation();
}

function updateComprehensiveNavigation() {
    const currentStep = AppState.comprehensiveData.currentStep;
    const totalSteps = AppState.comprehensiveData.totalSteps;
    
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    const submitBtn = document.getElementById('submit-btn');
    
    // Update navigation buttons
    if (prevBtn) {
        prevBtn.disabled = currentStep === 1;
    }
    
    if (currentStep === totalSteps) {
        if (nextBtn) nextBtn.classList.add('hidden');
        if (submitBtn) submitBtn.classList.remove('hidden');
    } else {
        if (nextBtn) nextBtn.classList.remove('hidden');
        if (submitBtn) submitBtn.classList.add('hidden');
    }
}

function submitComprehensiveQuiz(e) {
    if (e) e.preventDefault();
    
    const results = calculateComprehensiveResults();
    showLoadingPage(() => {
        displayResults(results);
    });
}

function calculateComprehensiveResults() {
    const answers = AppState.comprehensiveData.answers;
    const matchedProducts = [];
    
    products.forEach(product => {
        let score = 0;
        let maxScore = 0;
        
        // Device type matching
        if (answers.device_type) {
            maxScore += 30;
            if (answers.device_type === 'laptop' && product.tags.includes('laptop')) score += 30;
            else if (answers.device_type === 'phone' && product.tags.includes('phone')) score += 30;
            else if (answers.device_type === 'tablet' && product.tags.includes('tablet')) score += 30;
            else if (answers.device_type === 'gaming' && product.tags.includes('gaming')) score += 30;
            else if (answers.device_type === 'other') score += 15;
        }
        
        // Manufacturer matching
        if (answers.manufacturer) {
            maxScore += 25;
            if (answers.manufacturer.toLowerCase() === product.manufacturer.toLowerCase()) score += 25;
            else if (answers.manufacturer === 'other') score += 12;
        }
        
        // Port type matching
        if (answers.port_type) {
            maxScore += 25;
            if (answers.port_type === product.port_type || 
                (answers.port_type === 'usbc' && product.port_type === 'usb-c')) score += 25;
            else if (answers.port_type === 'unsure') score += 10;
        }
        
        // Power needs
        if (answers.power_needs) {
            maxScore += 10;
            score += 10; // Simple power matching logic
        }
        
        // Budget matching
        if (answers.budget) {
            maxScore += 10;
            const [minBudget, maxBudget] = answers.budget;
            if (product.price >= minBudget && product.price <= maxBudget) {
                score += 10;
            } else if (product.price <= maxBudget + 20) {
                score += 5;
            }
        }
        
        const confidence = Math.max(40, Math.round((score / maxScore) * 100));
        
        if (confidence > 30 || !maxScore) {
            matchedProducts.push({
                ...product,
                confidence,
                explanation: generateExplanation(product, answers, confidence)
            });
        }
    });
    
    return matchedProducts.sort((a, b) => b.confidence - a.confidence).slice(0, 4);
}

function generateExplanation(product, answers, confidence) {
    const reasons = [];
    
    if (answers.manufacturer && answers.manufacturer.toLowerCase() === product.manufacturer.toLowerCase()) {
        reasons.push(`matches your preferred ${product.manufacturer} brand`);
    }
    
    if (answers.port_type && (answers.port_type === product.port_type || 
        (answers.port_type === 'usbc' && product.port_type === 'usb-c'))) {
        reasons.push(`has the ${product.port_type} port you specified`);
    }
    
    if (answers.budget) {
        const [minBudget, maxBudget] = answers.budget;
        if (product.price >= minBudget && product.price <= maxBudget) {
            reasons.push(`fits within your budget range`);
        }
    }
    
    if (answers.features && answers.features.length > 0) {
        const matchingFeatures = product.features.filter(feature => 
            answers.features.some(selectedFeature => 
                feature.toLowerCase().includes(selectedFeature.toLowerCase())
            )
        );
        if (matchingFeatures.length > 0) {
            reasons.push(`includes your desired features: ${matchingFeatures.join(', ')}`);
        }
    }
    
    if (reasons.length === 0) {
        return `This product is a ${confidence}% match based on your requirements.`;
    }
    
    return `This product ${reasons.join(' and ')}.`;
}

// Loading Page
function showLoadingPage(callback) {
    showPage('loading-page');
    
    const loadingTexts = [
        'Analyzing device compatibility...',
        'Checking power requirements...',
        'Matching connector types...',
        'Calculating confidence scores...',
        'Finalizing recommendations...'
    ];
    
    let textIndex = 0;
    const loadingText = document.getElementById('loading-text');
    const loadingFill = document.getElementById('loading-fill');
    
    if (loadingFill) {
        loadingFill.style.width = '0%';
    }
    
    const interval = setInterval(() => {
        if (textIndex < loadingTexts.length) {
            if (loadingText) {
                loadingText.textContent = loadingTexts[textIndex];
            }
            if (loadingFill) {
                loadingFill.style.width = `${(textIndex + 1) * 20}%`;
            }
            textIndex++;
        } else {
            clearInterval(interval);
            setTimeout(callback, 500);
        }
    }, 600);
}

// Results Display
function displayResults(results) {
    const container = document.getElementById('results-container');
    if (!container) return;
    
    container.innerHTML = '';
    
    results.forEach((product, index) => {
        const resultCard = createResultCard(product, index === 0);
        container.appendChild(resultCard);
    });
    
    showPage('results-page');
}

function createResultCard(product, isBestMatch = false) {
    const card = document.createElement('div');
    card.className = `result-card ${isBestMatch ? 'best-match' : ''}`;
    
    const stars = '★'.repeat(Math.floor(product.rating)) + 
                 (product.rating % 1 >= 0.5 ? '☆' : '') + 
                 '☆'.repeat(5 - Math.ceil(product.rating));
    
    card.innerHTML = `
        <img src="${product.image}" alt="${product.title}" class="result-image" 
             onerror="this.style.background='var(--color-bg-3)'; this.style.display='flex'; this.style.alignItems='center'; this.style.justifyContent='center'; this.textContent='📱';">
        <div class="result-content">
            <div class="result-header">
                <h3 class="result-title">${product.title}</h3>
                <div class="result-price">$${product.price.toFixed(2)}</div>
            </div>
            <div class="result-manufacturer">${product.manufacturer}</div>
            <div class="result-rating">
                <span class="stars">${stars}</span>
                <span class="rating-text">${product.rating}/5</span>
            </div>
            <div class="confidence-score">
                <div class="confidence-score-value">${product.confidence}%</div>
                <div class="confidence-score-label">AI Confidence</div>
            </div>
            <div class="result-features">
                <div class="feature-tags">
                    ${product.features.map(feature => `<span class="feature-tag">${feature}</span>`).join('')}
                </div>
            </div>
            <p style="font-size: var(--font-size-sm); color: var(--color-text-secondary); margin-bottom: var(--space-16);">
                ${product.explanation}
            </p>
            <div class="result-actions">
                <button class="btn btn--primary btn--sm" onclick="window.open('https://example.com/product/${product.id}', '_blank')">
                    View Product
                </button>
                <button class="btn btn--outline btn--sm" onclick="showProductDetails('${product.id}')">
                    Details
                </button>
            </div>
        </div>
    `;
    
    return card;
}

// Product Database
function showProductDatabase() {
    renderProductsGrid();
    showPage('database-page');
}

function renderProductsGrid() {
    const container = document.getElementById('products-grid');
    if (!container) return;
    
    container.innerHTML = '';
    
    AppState.filteredProducts.forEach(product => {
        const productCard = createProductCard(product);
        container.appendChild(productCard);
    });
}

function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    const stars = '★'.repeat(Math.floor(product.rating)) + 
                 (product.rating % 1 >= 0.5 ? '☆' : '') + 
                 '☆'.repeat(5 - Math.ceil(product.rating));
    
    card.innerHTML = `
        <img src="${product.image}" alt="${product.title}" class="product-image"
             onerror="this.style.background='var(--color-bg-4)'; this.style.display='flex'; this.style.alignItems='center'; this.style.justifyContent='center'; this.textContent='⚡';">
        <div class="product-info">
            <h4 class="product-title">${product.title}</h4>
            <div class="product-manufacturer">${product.manufacturer}</div>
            <div class="product-price">$${product.price.toFixed(2)}</div>
            <div class="result-rating" style="margin-bottom: var(--space-8);">
                <span class="stars">${stars}</span>
                <span class="rating-text">${product.rating}/5</span>
            </div>
            <div class="product-compatibility">
                <div class="compatibility-label">Compatible with:</div>
                <div class="compatibility-list">${product.compatibility.join(', ')}</div>
            </div>
            <div class="feature-tags">
                ${product.features.slice(0, 3).map(feature => `<span class="feature-tag">${feature}</span>`).join('')}
            </div>
        </div>
    `;
    
    return card;
}

function filterProducts() {
    const searchTerm = document.getElementById('product-search').value.toLowerCase();
    const manufacturerFilter = document.getElementById('filter-manufacturer').value;
    
    AppState.filteredProducts = AppState.products.filter(product => {
        const matchesSearch = searchTerm === '' || 
            product.title.toLowerCase().includes(searchTerm) ||
            product.manufacturer.toLowerCase().includes(searchTerm) ||
            product.tags.some(tag => tag.toLowerCase().includes(searchTerm));
            
        const matchesManufacturer = manufacturerFilter === '' || 
            product.manufacturer === manufacturerFilter;
            
        return matchesSearch && matchesManufacturer;
    });
    
    renderProductsGrid();
}

// Utility Functions
function showProductDetails(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        alert(`${product.title}\n\nManufacturer: ${product.manufacturer}\nPrice: $${product.price}\nRating: ${product.rating}/5\n\nCompatibility: ${product.compatibility.join(', ')}\n\nFeatures: ${product.features.join(', ')}`);
    }
}

// Add visual feedback for interactions
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('btn')) {
        e.target.style.transform = 'scale(0.95)';
        setTimeout(() => {
            e.target.style.transform = '';
        }, 150);
    }
});

// Add keyboard navigation support
document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && e.target.classList.contains('option-card')) {
        const radio = e.target.querySelector('input[type="radio"]');
        const checkbox = e.target.querySelector('input[type="checkbox"]');
        
        if (radio) {
            radio.checked = true;
            radio.dispatchEvent(new Event('change'));
        } else if (checkbox) {
            checkbox.checked = !checkbox.checked;
            checkbox.dispatchEvent(new Event('change'));
        }
    }
});

// Initialize tooltips and enhanced interactions
setTimeout(() => {
    document.querySelectorAll('.option-card').forEach(card => {
        card.setAttribute('tabindex', '0');
        card.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
            }
        });
    });
}, 100);