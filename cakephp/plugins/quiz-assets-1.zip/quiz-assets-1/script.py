# Let's create a comprehensive JSON quiz structure for finding the right adapter/charger/cord
# Based on the fields shown in the image

import json
from datetime import datetime

# Define the comprehensive quiz structure
quiz_structure = {
    "quiz_info": {
        "title": "Smart Adapter & Charger Finder Quiz",
        "description": "AI-powered quiz to find the perfect adapter, charger, or cord for your device",
        "version": "1.0",
        "ai_enabled": True,
        "created": datetime.now().isoformat(),
        "estimated_time": "2-3 minutes"
    },
    
    "quiz_flow": {
        "total_questions": 8,
        "branching_enabled": True,
        "ai_recommendations": True,
        "confidence_scoring": True
    },
    
    "questions": [
        {
            "id": "q1",
            "type": "single_choice",
            "category": "device_type",
            "question": "What type of device do you need a charger/adapter for?",
            "weight": 10,
            "required": True,
            "options": [
                {
                    "id": "laptop",
                    "label": "Laptop/MacBook",
                    "value": "laptop",
                    "next_question": "q2_laptop",
                    "filters": {
                        "device_cat": ["laptop", "macbook", "notebook"],
                        "form_factor": ["ac_adapter", "power_brick"]
                    }
                },
                {
                    "id": "phone",
                    "label": "Phone/Mobile Device",
                    "value": "phone",
                    "next_question": "q2_mobile",
                    "filters": {
                        "device_cat": ["phone", "mobile", "smartphone"],
                        "form_factor": ["cable", "wireless_charger"]
                    }
                },
                {
                    "id": "tablet",
                    "label": "Tablet/iPad",
                    "value": "tablet", 
                    "next_question": "q2_tablet",
                    "filters": {
                        "device_cat": ["tablet", "ipad"],
                        "port_type": ["usb-c", "lightning", "micro-usb"]
                    }
                },
                {
                    "id": "gaming",
                    "label": "Gaming Console/Graphics Card",
                    "value": "gaming",
                    "next_question": "q2_gaming",
                    "filters": {
                        "device_cat": ["gaming", "gpu", "console"],
                        "manufacturer": ["nvidia", "amd", "sony", "microsoft"]
                    }
                },
                {
                    "id": "other",
                    "label": "Other Electronic Device",
                    "value": "other",
                    "next_question": "q2_other",
                    "filters": {}
                }
            ]
        },
        
        {
            "id": "q2_laptop",
            "type": "single_choice",
            "category": "manufacturer",
            "question": "What's the manufacturer of your laptop?",
            "weight": 9,
            "required": True,
            "conditional_display": {
                "depends_on": "q1",
                "show_if": "laptop"
            },
            "options": [
                {
                    "id": "apple",
                    "label": "Apple (MacBook)",
                    "value": "apple",
                    "filters": {
                        "manufacturer": ["apple"],
                        "device_compatibility": ["macbook", "mac"]
                    }
                },
                {
                    "id": "dell",
                    "label": "Dell",
                    "value": "dell",
                    "filters": {"manufacturer": ["dell"]}
                },
                {
                    "id": "hp",
                    "label": "HP",
                    "value": "hp", 
                    "filters": {"manufacturer": ["hp"]}
                },
                {
                    "id": "lenovo",
                    "label": "Lenovo",
                    "value": "lenovo",
                    "filters": {"manufacturer": ["lenovo"]}
                },
                {
                    "id": "asus",
                    "label": "ASUS",
                    "value": "asus",
                    "filters": {"manufacturer": ["asus"]}
                }
            ]
        },
        
        {
            "id": "q3",
            "type": "single_choice",
            "category": "port_type",
            "question": "What type of charging port does your device have?",
            "weight": 8,
            "required": True,
            "options": [
                {
                    "id": "usbc",
                    "label": "USB-C",
                    "value": "usb-c",
                    "image": "usb-c-port.jpg",
                    "filters": {"port_type": ["usb-c", "type-c"]}
                },
                {
                    "id": "lightning",
                    "label": "Lightning (iPhone/iPad)",
                    "value": "lightning",
                    "image": "lightning-port.jpg", 
                    "filters": {"port_type": ["lightning"]}
                },
                {
                    "id": "microusb",
                    "label": "Micro USB",
                    "value": "micro-usb",
                    "image": "micro-usb-port.jpg",
                    "filters": {"port_type": ["micro-usb"]}
                },
                {
                    "id": "magsafe",
                    "label": "MagSafe (MacBook)",
                    "value": "magsafe",
                    "image": "magsafe-port.jpg",
                    "filters": {"port_type": ["magsafe", "magsafe2"]}
                },
                {
                    "id": "proprietary",
                    "label": "Proprietary/Custom Port",
                    "value": "proprietary",
                    "filters": {"port_type": ["proprietary", "custom"]}
                },
                {
                    "id": "unsure",
                    "label": "I'm not sure",
                    "value": "unsure",
                    "next_question": "q3_help"
                }
            ]
        },
        
        {
            "id": "q4",
            "type": "single_choice",
            "category": "power_requirements",
            "question": "What are your device's power requirements?",
            "weight": 7,
            "required": False,
            "help_text": "Check your device specifications or existing charger for wattage",
            "options": [
                {
                    "id": "low_power",
                    "label": "Low Power (5W-18W) - Phones, small devices",
                    "value": "5-18w",
                    "filters": {"power_output": {"min": 5, "max": 18}}
                },
                {
                    "id": "medium_power",
                    "label": "Medium Power (20W-65W) - Tablets, ultrabooks",
                    "value": "20-65w",
                    "filters": {"power_output": {"min": 20, "max": 65}}
                },
                {
                    "id": "high_power",
                    "label": "High Power (70W+) - Gaming laptops, workstations",
                    "value": "70w+",
                    "filters": {"power_output": {"min": 70, "max": 300}}
                },
                {
                    "id": "unknown",
                    "label": "I don't know",
                    "value": "unknown"
                }
            ]
        },
        
        {
            "id": "q5",
            "type": "multiple_choice",
            "category": "features",
            "question": "What additional features do you need? (Select all that apply)",
            "weight": 6,
            "required": False,
            "options": [
                {
                    "id": "fast_charging",
                    "label": "Fast Charging Support",
                    "value": "fast_charging",
                    "filters": {"features": ["fast_charge", "quick_charge", "pd"]}
                },
                {
                    "id": "multiple_ports",
                    "label": "Multiple Charging Ports",
                    "value": "multiple_ports",
                    "filters": {"features": ["multi_port", "hub"]}
                },
                {
                    "id": "wireless",
                    "label": "Wireless Charging",
                    "value": "wireless",
                    "filters": {"features": ["wireless", "qi_charging"]}
                },
                {
                    "id": "portable",
                    "label": "Compact/Portable Design",
                    "value": "portable",
                    "filters": {"form_factor": ["compact", "portable", "travel"]}
                },
                {
                    "id": "certification",
                    "label": "Official Certification (MFi, etc.)",
                    "value": "certified",
                    "filters": {"certified": [True]}
                }
            ]
        },
        
        {
            "id": "q6",
            "type": "range_slider",
            "category": "budget",
            "question": "What's your budget range?",
            "weight": 5,
            "required": True,
            "min_value": 5,
            "max_value": 500,
            "step": 5,
            "currency": "USD",
            "default_range": [20, 80],
            "filters": {
                "price_range": "dynamic"
            }
        },
        
        {
            "id": "q7",
            "type": "single_choice",
            "category": "urgency",
            "question": "How soon do you need this item?",
            "weight": 4,
            "required": False,
            "options": [
                {
                    "id": "asap",
                    "label": "ASAP (Same/Next day)",
                    "value": "urgent",
                    "filters": {"shipping": ["same_day", "next_day"]}
                },
                {
                    "id": "week",
                    "label": "Within a week",
                    "value": "normal",
                    "filters": {"shipping": ["standard"]}
                },
                {
                    "id": "flexible",
                    "label": "I'm flexible with timing",
                    "value": "flexible",
                    "filters": {"shipping": ["economy"]}
                }
            ]
        },
        
        {
            "id": "q8",
            "type": "rating_scale",
            "category": "priorities",
            "question": "Rate the importance of these factors (1-5 scale)",
            "weight": 3,
            "required": False,
            "sub_questions": [
                {
                    "id": "price_importance",
                    "label": "Low Price",
                    "max_rating": 5
                },
                {
                    "id": "quality_importance", 
                    "label": "Build Quality",
                    "max_rating": 5
                },
                {
                    "id": "brand_importance",
                    "label": "Brand Recognition", 
                    "max_rating": 5
                },
                {
                    "id": "speed_importance",
                    "label": "Charging Speed",
                    "max_rating": 5
                }
            ]
        }
    ],
    
    "ai_matching_algorithm": {
        "scoring_method": "weighted_confidence",
        "minimum_match_score": 0.6,
        "max_results": 5,
        "factors": {
            "exact_compatibility": 0.4,
            "feature_match": 0.25,
            "price_fit": 0.15,
            "user_ratings": 0.1,
            "availability": 0.1
        },
        "ai_learning": {
            "track_user_selections": True,
            "improve_recommendations": True,
            "feedback_collection": True
        }
    },
    
    "result_display": {
        "show_confidence_score": True,
        "show_comparison_table": True,
        "include_alternatives": True,
        "ai_explanation": True,
        "purchase_links": True,
        "save_results": True
    },
    
    "database_fields_mapping": {
        "title": "title",
        "manufacturer": "manufacturer", 
        "port_type": "port_type",
        "form_factor": "form_factor",
        "device_gender": "device_gender",
        "device_category": "device_cat",
        "compatibility": "device_compatibility",
        "price": "price",
        "rating": "rating",
        "certified": "certified",
        "status": "status",
        "relevance_score": "rel_score",
        "views": "views",
        "created_date": "created",
        "actions": "actions"
    }
}

# Save the quiz structure to a JSON file
with open('adapter_finder_quiz_structure.json', 'w') as f:
    json.dump(quiz_structure, f, indent=2, default=str)

print("✅ Comprehensive quiz structure created!")
print("📊 Quiz includes:")
print(f"   • {len(quiz_structure['questions'])} adaptive questions")
print(f"   • AI-powered matching algorithm")
print(f"   • Support for {len(quiz_structure['database_fields_mapping'])} database fields")
print(f"   • Confidence scoring and learning capabilities")
print("\n📁 File saved as: adapter_finder_quiz_structure.json")