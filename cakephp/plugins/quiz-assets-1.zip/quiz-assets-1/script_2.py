# Create Akinator-style quiz structure for adapter/charger finder
# Binary yes/no questions that efficiently narrow down the product space

akinator_quiz_structure = {
    "quiz_info": {
        "title": "AI Adapter Genie - Find Your Perfect Match!",
        "description": "Think of the device you need a charger for, and I'll guess the exact adapter you need!",
        "version": "2.0",
        "style": "akinator",
        "ai_enabled": True,
        "binary_questions": True,
        "max_questions": 20,
        "confidence_threshold": 0.85
    },
    
    "akinator_questions": [
        {
            "id": "q1",
            "question": "Is your device something you can hold in one hand?",
            "type": "binary",
            "weight": 10,
            "eliminates_percentage": 60,
            "yes_filters": {
                "device_cat": ["phone", "mobile", "smartphone", "small_tablet", "earbuds", "smartwatch"],
                "size_category": "handheld"
            },
            "no_filters": {
                "device_cat": ["laptop", "desktop", "monitor", "tablet", "gaming_console", "large_device"],
                "size_category": "large"
            },
            "yes_next": "q2_handheld",
            "no_next": "q2_large"
        },
        
        {
            "id": "q2_handheld", 
            "question": "Does your device make phone calls?",
            "type": "binary",
            "weight": 9,
            "depends_on": {"q1": "yes"},
            "eliminates_percentage": 40,
            "yes_filters": {
                "device_cat": ["phone", "smartphone"],
                "has_cellular": True
            },
            "no_filters": {
                "device_cat": ["tablet", "earbuds", "smartwatch", "media_player", "camera"],
                "has_cellular": False
            },
            "yes_next": "q3_phone",
            "no_next": "q3_non_phone_handheld"
        },
        
        {
            "id": "q2_large",
            "question": "Is it primarily used for computing or work?", 
            "type": "binary",
            "weight": 9,
            "depends_on": {"q1": "no"},
            "eliminates_percentage": 50,
            "yes_filters": {
                "device_cat": ["laptop", "desktop", "workstation", "server"],
                "primary_use": "computing"
            },
            "no_filters": {
                "device_cat": ["tv", "monitor", "gaming_console", "audio_equipment", "appliance"],
                "primary_use": "entertainment"
            },
            "yes_next": "q3_computer",
            "no_next": "q3_entertainment"
        },
        
        {
            "id": "q3_phone",
            "question": "Does it have a round home button on the front?",
            "type": "binary", 
            "weight": 8,
            "depends_on": {"q2_handheld": "yes"},
            "eliminates_percentage": 70,
            "yes_filters": {
                "manufacturer": ["apple"],
                "device_model": ["iphone_6", "iphone_7", "iphone_8"],
                "port_type": ["lightning"],
                "has_home_button": True
            },
            "no_filters": {
                "manufacturer": ["apple", "samsung", "google", "oneplus", "xiaomi"],
                "device_model": ["iphone_x_plus", "android_phones"],
                "port_type": ["usb-c", "lightning"],
                "has_home_button": False
            },
            "yes_next": "q4_old_iphone",
            "no_next": "q4_modern_phone"
        },
        
        {
            "id": "q4_modern_phone",
            "question": "Does your phone charge with the same cable as most Android phones?",
            "type": "binary",
            "weight": 8,
            "depends_on": {"q3_phone": "no"},
            "eliminates_percentage": 85,
            "yes_filters": {
                "port_type": ["usb-c"],
                "manufacturer": ["samsung", "google", "oneplus", "xiaomi", "huawei"],
                "connector_type": "usb-c"
            },
            "no_filters": {
                "port_type": ["lightning", "micro-usb"],
                "manufacturer": ["apple"],
                "connector_type": "lightning"
            },
            "yes_next": "q5_android_usbc",
            "no_next": "q5_iphone_lightning"
        },
        
        {
            "id": "q3_computer",
            "question": "Is it made by Apple?",
            "type": "binary",
            "weight": 8,
            "depends_on": {"q2_large": "yes"},
            "eliminates_percentage": 40,
            "yes_filters": {
                "manufacturer": ["apple"],
                "device_cat": ["macbook", "imac", "mac_mini"],
                "port_type": ["magsafe", "usb-c", "magsafe2"]
            },
            "no_filters": {
                "manufacturer": ["dell", "hp", "lenovo", "asus", "acer"],
                "device_cat": ["laptop", "desktop"],
                "port_type": ["proprietary", "usb-c", "barrel"]
            },
            "yes_next": "q4_mac",
            "no_next": "q4_pc"
        },
        
        {
            "id": "q4_mac",
            "question": "Does it have a glowing Apple logo on the back?",
            "type": "binary",
            "weight": 7,
            "depends_on": {"q3_computer": "yes"},
            "eliminates_percentage": 60,
            "yes_filters": {
                "device_cat": ["macbook"],
                "form_factor": ["laptop"],
                "has_logo": True,
                "port_type": ["magsafe", "magsafe2", "usb-c"]
            },
            "no_filters": {
                "device_cat": ["imac", "mac_mini", "mac_pro"],
                "form_factor": ["desktop"],
                "has_logo": False
            },
            "yes_next": "q5_macbook",
            "no_next": "q5_mac_desktop"
        },
        
        {
            "id": "q5_macbook",
            "question": "Does it charge with a magnetic connector?",
            "type": "binary",
            "weight": 7,
            "depends_on": {"q4_mac": "yes"},
            "eliminates_percentage": 80,
            "yes_filters": {
                "port_type": ["magsafe", "magsafe2"],
                "connector_type": "magnetic",
                "device_generation": ["older"]
            },
            "no_filters": {
                "port_type": ["usb-c"],
                "connector_type": "usb-c",
                "device_generation": ["newer"]
            },
            "yes_next": "q6_magsafe",
            "no_next": "q6_usbc_mac"
        },
        
        {
            "id": "q6_magsafe",
            "question": "Is the magnetic connector shaped like a 'T'?",
            "type": "binary",
            "weight": 6,
            "depends_on": {"q5_macbook": "yes"},
            "eliminates_percentage": 90,
            "yes_filters": {
                "port_type": ["magsafe2"],
                "connector_shape": "t_shape",
                "device_year": ["2012-2015"]
            },
            "no_filters": {
                "port_type": ["magsafe"],
                "connector_shape": "l_shape", 
                "device_year": ["2006-2012"]
            },
            "yes_next": "q7_magsafe2",
            "no_next": "q7_magsafe1"
        },
        
        {
            "id": "q4_pc",
            "question": "Is it a gaming laptop with RGB lighting?",
            "type": "binary",
            "weight": 7,
            "depends_on": {"q3_computer": "no"},
            "eliminates_percentage": 30,
            "yes_filters": {
                "device_cat": ["gaming_laptop"],
                "power_requirements": ["high_power"],
                "wattage": {"min": 120, "max": 330},
                "has_rgb": True
            },
            "no_filters": {
                "device_cat": ["business_laptop", "ultrabook"],
                "power_requirements": ["low_power", "medium_power"],
                "wattage": {"min": 45, "max": 90},
                "has_rgb": False
            },
            "yes_next": "q5_gaming",
            "no_next": "q5_business_laptop"
        },
        
        {
            "id": "q5_android_usbc",
            "question": "Does your phone support super-fast charging (65W or higher)?",
            "type": "binary",
            "weight": 7,
            "depends_on": {"q4_modern_phone": "yes"},
            "eliminates_percentage": 70,
            "yes_filters": {
                "fast_charging": True,
                "wattage": {"min": 65, "max": 150},
                "manufacturer": ["oneplus", "xiaomi", "oppo"],
                "charging_speed": "superfast"
            },
            "no_filters": {
                "fast_charging": False,
                "wattage": {"min": 18, "max": 45},
                "manufacturer": ["samsung", "google"],
                "charging_speed": "standard"
            },
            "yes_next": "q6_superfast",
            "no_next": "q6_standard_android"
        },
        
        {
            "id": "q5_iphone_lightning",
            "question": "Was your iPhone released in 2020 or later?",
            "type": "binary",
            "weight": 7,
            "depends_on": {"q4_modern_phone": "no"},
            "eliminates_percentage": 75,
            "yes_filters": {
                "device_year": ["2020", "2021", "2022", "2023", "2024"],
                "device_model": ["iphone_12", "iphone_13", "iphone_14", "iphone_15"],
                "fast_charging": True
            },
            "no_filters": {
                "device_year": ["2017", "2018", "2019"],
                "device_model": ["iphone_x", "iphone_xr", "iphone_11"],
                "fast_charging": False
            },
            "yes_next": "q6_new_iphone",
            "no_next": "q6_older_iphone"
        },
        
        {
            "id": "q3_non_phone_handheld",
            "question": "Do you put it in your ears?",
            "type": "binary",
            "weight": 8,
            "depends_on": {"q2_handheld": "no"},
            "eliminates_percentage": 60,
            "yes_filters": {
                "device_cat": ["earbuds", "headphones"],
                "device_type": "audio",
                "placement": "ears"
            },
            "no_filters": {
                "device_cat": ["tablet", "e_reader", "camera", "smartwatch"],
                "device_type": "visual",
                "placement": "external"
            },
            "yes_next": "q4_audio",
            "no_next": "q4_visual_handheld"
        },
        
        {
            "id": "q4_audio",
            "question": "Are they completely wireless (no cord between earbuds)?",
            "type": "binary",
            "weight": 7,
            "depends_on": {"q3_non_phone_handheld": "yes"},
            "eliminates_percentage": 80,
            "yes_filters": {
                "device_cat": ["true_wireless_earbuds"],
                "connection_type": "true_wireless",
                "manufacturer": ["apple", "samsung", "sony", "bose"]
            },
            "no_filters": {
                "device_cat": ["wireless_headphones"],
                "connection_type": "wireless_with_band",
                "has_connecting_wire": True
            },
            "yes_next": "q5_airpods_style",
            "no_next": "q5_headphones"
        },
        
        {
            "id": "q5_airpods_style", 
            "question": "Do they come in a small white case?",
            "type": "binary",
            "weight": 6,
            "depends_on": {"q4_audio": "yes"},
            "eliminates_percentage": 85,
            "yes_filters": {
                "manufacturer": ["apple"],
                "device_model": ["airpods", "airpods_pro"],
                "case_color": "white",
                "port_type": ["lightning", "usb-c"]
            },
            "no_filters": {
                "manufacturer": ["samsung", "sony", "bose", "jabra"],
                "device_model": ["galaxy_buds", "wf_series"],
                "case_color": "black",
                "port_type": ["usb-c", "micro-usb"]
            },
            "yes_next": "q6_airpods",
            "no_next": "q6_other_earbuds"
        },
        
        {
            "id": "q6_airpods",
            "question": "Does the case charge with the same cable as newer iPhones?", 
            "type": "binary",
            "weight": 5,
            "depends_on": {"q5_airpods_style": "yes"},
            "eliminates_percentage": 90,
            "yes_filters": {
                "device_model": ["airpods_usb_c", "airpods_pro_2nd_gen"],
                "port_type": ["usb-c"],
                "release_year": ["2023", "2024"]
            },
            "no_filters": {
                "device_model": ["airpods_lightning", "airpods_pro_1st_gen"],
                "port_type": ["lightning"],
                "release_year": ["2019", "2020", "2021", "2022"]
            },
            "yes_next": "result_airpods_usbc",
            "no_next": "result_airpods_lightning"
        },
        
        # Results/Recommendations
        {
            "id": "result_airpods_usbc",
            "question": null,
            "type": "result",
            "confidence": 0.95,
            "recommendation": {
                "product_type": "USB-C to USB-C Cable + 20W USB-C Power Adapter",
                "specific_products": [
                    "Apple 20W USB-C Power Adapter",
                    "USB-C to USB-C Cable (1m)",
                    "Anker PowerPort III 20W"
                ],
                "explanation": "Your AirPods case with USB-C requires a USB-C cable and 20W power adapter for optimal charging.",
                "price_range": "$15-45",
                "compatibility": ["AirPods Pro 2nd Gen", "AirPods 3rd Gen with USB-C"]
            }
        },
        
        {
            "id": "result_airpods_lightning",
            "question": null,
            "type": "result", 
            "confidence": 0.93,
            "recommendation": {
                "product_type": "Lightning to USB-A/C Cable + Power Adapter",
                "specific_products": [
                    "Apple Lightning to USB Cable",
                    "Apple 5W USB Power Adapter", 
                    "Anker PowerPort 12W"
                ],
                "explanation": "Your AirPods case with Lightning port needs a Lightning cable and can use any USB power adapter.",
                "price_range": "$12-35",
                "compatibility": ["AirPods 1st Gen", "AirPods 2nd Gen", "AirPods Pro 1st Gen"]
            }
        }
    ],
    
    "ai_decision_tree": {
        "algorithm": "binary_elimination",
        "learning_enabled": True,
        "confidence_calculation": "bayesian",
        "question_selection": "maximum_information_gain",
        "early_termination": True,
        "min_confidence": 0.85
    },
    
    "akinator_ui_elements": {
        "show_lamp_animation": True,
        "show_thinking_animation": True,
        "play_sound_effects": False,
        "show_confidence_meter": True,
        "show_remaining_questions": True,
        "enable_answer_undo": True,
        "show_genie_responses": [
            "Hmm, interesting...",
            "I'm getting closer!",
            "This narrows it down significantly!",
            "Almost there!",
            "I think I know what you need!"
        ]
    }
}

# Save the Akinator-style quiz
with open('akinator_adapter_quiz.json', 'w') as f:
    json.dump(akinator_quiz_structure, f, indent=2, default=str)

print("🧞‍♂️ Akinator-style Adapter Finder Quiz created!")
print("📊 Quiz features:")
print(f"   • Binary yes/no questions like Akinator")
print(f"   • Decision tree algorithm for efficient elimination") 
print(f"   • Maximum {akinator_quiz_structure['quiz_info']['max_questions']} questions")
print(f"   • Confidence threshold: {akinator_quiz_structure['quiz_info']['confidence_threshold']}")
print(f"   • AI learning and adaptation enabled")
print("\n🎯 Question examples:")
for q in akinator_quiz_structure['akinator_questions'][:5]:
    if q['question']:
        print(f"   • {q['question']}")

print(f"\n📁 File saved as: akinator_adapter_quiz.json")