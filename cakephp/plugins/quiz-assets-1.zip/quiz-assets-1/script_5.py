# Create the Formidable Forms integration plugin
formidable_integration = """<?php
/**
 * AI Adapter Finder - Formidable Forms Integration
 * 
 * @package AI_Adapter_Finder_Pro
 * @subpackage Formidable_Integration
 */

if (!defined('ABSPATH')) {
    exit;
}

class AI_Adapter_Finder_Formidable_Integration {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Hook into Formidable Forms
        add_action('frm_registered_form_actions', array($this, 'register_form_action'));
        add_filter('frm_form_fields', array($this, 'add_custom_fields'), 10, 2);
        add_action('frm_after_create_entry', array($this, 'process_quiz_submission'), 10, 2);
        add_action('wp_ajax_frm_ai_adapter_quiz', array($this, 'handle_ajax_quiz'));
        add_action('wp_ajax_nopriv_frm_ai_adapter_quiz', array($this, 'handle_ajax_quiz'));
        
        // Add custom field types
        add_filter('frm_available_fields', array($this, 'add_adapter_quiz_field'));
        add_action('frm_field_options_form', array($this, 'field_options_form'), 10, 3);
        
        // Enqueue scripts for Formidable integration
        add_action('frm_enqueue_form_scripts', array($this, 'enqueue_form_scripts'));
    }
    
    /**
     * Register the AI Adapter Quiz action with Formidable Forms
     */
    public function register_form_action($actions) {
        $actions['ai_adapter_quiz'] = 'AI_Adapter_Quiz_Action';
        return $actions;
    }
    
    /**
     * Add custom adapter quiz field to Formidable Forms
     */
    public function add_adapter_quiz_field($fields) {
        $fields['ai_adapter_quiz'] = array(
            'name' => __('AI Adapter Quiz', 'ai-adapter-finder'),
            'icon' => 'frm_icon_font frm-search-plus',
            'ajax' => true
        );
        return $fields;
    }
    
    /**
     * Add custom field options in the form builder
     */
    public function field_options_form($field, $display, $values) {
        if ($field['type'] != 'ai_adapter_quiz') {
            return;
        }
        
        include(AI_ADAPTER_FINDER_PLUGIN_PATH . 'includes/formidable/field-options.php');
    }
    
    /**
     * Process quiz submission when form is submitted
     */
    public function process_quiz_submission($entry_id, $form_id) {
        // Check if this form contains our AI adapter quiz field
        $form = FrmForm::getOne($form_id);
        $fields = FrmField::get_all_for_form($form_id);
        
        $has_quiz_field = false;
        foreach ($fields as $field) {
            if ($field->type == 'ai_adapter_quiz') {
                $has_quiz_field = true;
                break;
            }
        }
        
        if (!$has_quiz_field) {
            return;
        }
        
        // Get quiz responses
        $entry = FrmEntry::getOne($entry_id);
        $quiz_data = $this->extract_quiz_data($entry_id);
        
        // Process with AI matching engine
        $ai_engine = new AI_Matching_Engine();
        $recommendations = $ai_engine->find_matches($quiz_data);
        
        // Save recommendations to entry meta
        FrmEntryMeta::add_entry_meta($entry_id, 0, 'ai_recommendations', serialize($recommendations));
        FrmEntryMeta::add_entry_meta($entry_id, 0, 'confidence_scores', serialize($ai_engine->get_confidence_scores()));
        
        // Send results email if configured
        $this->send_results_email($entry_id, $recommendations);
    }
    
    /**
     * Handle AJAX requests for real-time quiz interactions
     */
    public function handle_ajax_quiz() {
        check_ajax_referer('frm_ajax', 'nonce');
        
        $action = sanitize_text_field($_POST['quiz_action']);
        
        switch ($action) {
            case 'next_question':
                $this->handle_next_question();
                break;
            case 'get_recommendations':
                $this->handle_get_recommendations();
                break;
            case 'save_progress':
                $this->handle_save_progress();
                break;
            default:
                wp_send_json_error('Invalid action');
        }
    }
    
    private function handle_next_question() {
        $current_answers = $_POST['answers'];
        $quiz_type = $_POST['quiz_type']; // 'comprehensive' or 'akinator'
        
        if ($quiz_type === 'akinator') {
            $quiz_data = json_decode(file_get_contents(AI_ADAPTER_FINDER_PLUGIN_PATH . 'data/akinator_adapter_quiz.json'), true);
        } else {
            $quiz_data = json_decode(file_get_contents(AI_ADAPTER_FINDER_PLUGIN_PATH . 'data/adapter_finder_quiz_structure.json'), true);
        }
        
        // Determine next question based on current answers
        $next_question = $this->determine_next_question($current_answers, $quiz_data);
        
        wp_send_json_success(array(
            'question' => $next_question,
            'progress' => $this->calculate_progress($current_answers, $quiz_data),
            'confidence' => $this->calculate_current_confidence($current_answers)
        ));
    }
    
    private function handle_get_recommendations() {
        $answers = $_POST['answers'];
        
        $ai_engine = new AI_Matching_Engine();
        $recommendations = $ai_engine->find_matches($answers);
        
        wp_send_json_success(array(
            'recommendations' => $recommendations,
            'confidence_scores' => $ai_engine->get_confidence_scores(),
            'explanation' => $ai_engine->get_explanation()
        ));
    }
    
    /**
     * Enqueue scripts for Formidable Forms integration
     */
    public function enqueue_form_scripts() {
        wp_enqueue_script(
            'ai-adapter-formidable',
            AI_ADAPTER_FINDER_PLUGIN_URL . 'assets/js/formidable-integration.js',
            array('jquery', 'frm-js'),
            AI_ADAPTER_FINDER_VERSION,
            true
        );
        
        wp_localize_script('ai-adapter-formidable', 'aiAdapterFormidable', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('frm_ajax'),
            'strings' => array(
                'thinking' => __('Thinking...', 'ai-adapter-finder'),
                'loading' => __('Loading recommendations...', 'ai-adapter-finder'),
                'error' => __('Something went wrong. Please try again.', 'ai-adapter-finder')
            )
        ));
        
        wp_enqueue_style(
            'ai-adapter-formidable-css',
            AI_ADAPTER_FINDER_PLUGIN_URL . 'assets/css/formidable-quiz.css',
            array(),
            AI_ADAPTER_FINDER_VERSION
        );
    }
    
    /**
     * Extract quiz data from form entry
     */
    private function extract_quiz_data($entry_id) {
        $metas = FrmEntryMeta::getAll(array('it.entry_id' => $entry_id), '', 'key');
        $quiz_data = array();
        
        foreach ($metas as $meta) {
            if (strpos($meta->field_id, 'quiz_') === 0) {
                $quiz_data[$meta->field_id] = $meta->meta_value;
            }
        }
        
        return $quiz_data;
    }
    
    /**
     * Send results email to user
     */
    private function send_results_email($entry_id, $recommendations) {
        $entry = FrmEntry::getOne($entry_id);
        
        // Get user email from entry
        $user_email = '';
        $metas = FrmEntryMeta::getAll(array('it.entry_id' => $entry_id));
        foreach ($metas as $meta) {
            $field = FrmField::getOne($meta->field_id);
            if ($field->type == 'email') {
                $user_email = $meta->meta_value;
                break;
            }
        }
        
        if (empty($user_email)) {
            return;
        }
        
        // Prepare email content
        $subject = __('Your AI Adapter Recommendations', 'ai-adapter-finder');
        $message = $this->build_results_email($recommendations);
        
        wp_mail($user_email, $subject, $message, array('Content-Type: text/html; charset=UTF-8'));
    }
    
    private function build_results_email($recommendations) {
        ob_start();
        include AI_ADAPTER_FINDER_PLUGIN_PATH . 'templates/email/quiz-results.php';
        return ob_get_clean();
    }
    
    /**
     * Determine the next question in the quiz flow
     */
    private function determine_next_question($current_answers, $quiz_data) {
        if ($quiz_data['quiz_info']['style'] === 'akinator') {
            return $this->determine_akinator_next_question($current_answers, $quiz_data);
        } else {
            return $this->determine_comprehensive_next_question($current_answers, $quiz_data);
        }
    }
    
    private function determine_akinator_next_question($current_answers, $quiz_data) {
        $questions = $quiz_data['akinator_questions'];
        
        // Find current question
        $current_question_id = end(array_keys($current_answers));
        if (!$current_question_id) {
            return $questions[0]; // First question
        }
        
        // Find the current question object
        $current_question = null;
        foreach ($questions as $q) {
            if ($q['id'] === $current_question_id) {
                $current_question = $q;
                break;
            }
        }
        
        if (!$current_question) {
            return null;
        }
        
        // Determine next question based on answer
        $answer = $current_answers[$current_question_id];
        $next_id = $answer === 'yes' ? $current_question['yes_next'] : $current_question['no_next'];
        
        // Find and return next question
        foreach ($questions as $q) {
            if ($q['id'] === $next_id) {
                return $q;
            }
        }
        
        return null; // End of quiz
    }
    
    private function determine_comprehensive_next_question($current_answers, $quiz_data) {
        $questions = $quiz_data['questions'];
        $answered_count = count($current_answers);
        
        // Simple sequential flow for comprehensive quiz
        if ($answered_count < count($questions)) {
            return $questions[$answered_count];
        }
        
        return null; // End of quiz
    }
    
    private function calculate_progress($current_answers, $quiz_data) {
        $total_questions = count($quiz_data['questions']);
        $answered = count($current_answers);
        
        return array(
            'current' => $answered,
            'total' => $total_questions,
            'percentage' => round(($answered / $total_questions) * 100, 0)
        );
    }
    
    private function calculate_current_confidence($current_answers) {
        // Simple confidence calculation based on number of answers
        $base_confidence = 0.3;
        $increment_per_answer = 0.05;
        
        return min(0.95, $base_confidence + (count($current_answers) * $increment_per_answer));
    }
}

/**
 * Custom Formidable Forms Action for AI Adapter Quiz
 */
class AI_Adapter_Quiz_Action extends FrmFormAction {
    
    public function __construct() {
        $action_ops = array(
            'classes'   => 'frm_ai_adapter_icon frm_icon_font',
            'limit'     => 1,
            'active'    => true,
            'priority'  => 50,
            'event'     => array('create', 'update'),
        );
        
        $this->FrmFormAction('ai_adapter_quiz', __('AI Adapter Quiz', 'ai-adapter-finder'), $action_ops);
    }
    
    public function form($form_action, $args = array()) {
        extract($args);
        
        $action_control = $this;
        $form_fields = FrmField::get_all_for_form($form->id);
        
        include(AI_ADAPTER_FINDER_PLUGIN_PATH . 'includes/formidable/action-form.php');
    }
    
    public function get_defaults() {
        return array(
            'ai_enabled' => 1,
            'quiz_type' => 'akinator',
            'show_confidence' => 1,
            'show_progress' => 1,
            'max_questions' => 20,
            'min_confidence' => 0.85,
            'send_email_results' => 0,
            'redirect_after_quiz' => '',
            'custom_css_class' => 'ai-adapter-quiz-form'
        );
    }
}

// Initialize the integration
AI_Adapter_Finder_Formidable_Integration::get_instance();
?>"""

# Save the Formidable Forms integration
with open('class-formidable-integration.php', 'w') as f:
    f.write(formidable_integration)

print("✅ Formidable Forms integration created!")
print("📄 File: class-formidable-integration.php")
print("🔧 Features:")
print("   • Custom AI Adapter Quiz field type")
print("   • Form action for quiz processing")
print("   • AJAX support for real-time interactions")
print("   • Email results functionality")
print("   • Support for both quiz types (Akinator + Comprehensive)")
print("   • Progress tracking and confidence scoring")
print("   • Custom field options in form builder")