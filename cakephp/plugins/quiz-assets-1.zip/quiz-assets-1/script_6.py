# Create the Elementor widget integration
elementor_integration = """<?php
/**
 * AI Adapter Finder - Elementor Widget Integration
 * 
 * @package AI_Adapter_Finder_Pro
 * @subpackage Elementor_Integration
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main Elementor Integration Class
 */
class AI_Adapter_Finder_Elementor_Integration {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('elementor/widgets/widgets_registered', array($this, 'register_widgets'));
        add_action('elementor/elements/categories_registered', array($this, 'add_elementor_widget_categories'));
        add_action('elementor/frontend/after_enqueue_styles', array($this, 'enqueue_widget_styles'));
        add_action('elementor/frontend/after_register_scripts', array($this, 'register_widget_scripts'));
    }
    
    /**
     * Register custom Elementor widgets
     */
    public function register_widgets() {
        // Check if Elementor is active
        if (!did_action('elementor/loaded')) {
            return;
        }
        
        // Register our custom widgets
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new AI_Adapter_Quiz_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new AI_Adapter_Results_Widget());
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new AI_Adapter_Search_Widget());
    }
    
    /**
     * Add custom widget category
     */
    public function add_elementor_widget_categories($elements_manager) {
        $elements_manager->add_category(
            'ai-adapter-finder',
            array(
                'title' => __('AI Adapter Finder', 'ai-adapter-finder'),
                'icon' => 'fa fa-search-plus',
            )
        );
    }
    
    /**
     * Enqueue widget styles
     */
    public function enqueue_widget_styles() {
        wp_enqueue_style(
            'ai-adapter-elementor-widgets',
            AI_ADAPTER_FINDER_PLUGIN_URL . 'assets/css/elementor-widgets.css',
            array(),
            AI_ADAPTER_FINDER_VERSION
        );
    }
    
    /**
     * Register widget scripts
     */
    public function register_widget_scripts() {
        wp_register_script(
            'ai-adapter-elementor-widgets',
            AI_ADAPTER_FINDER_PLUGIN_URL . 'assets/js/elementor-widgets.js',
            array('jquery', 'elementor-frontend'),
            AI_ADAPTER_FINDER_VERSION,
            true
        );
        
        wp_localize_script('ai-adapter-elementor-widgets', 'aiAdapterElementor', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_adapter_nonce'),
            'strings' => array(
                'loading' => __('Loading...', 'ai-adapter-finder'),
                'thinking' => __('AI is thinking...', 'ai-adapter-finder'),
                'error' => __('Something went wrong. Please try again.', 'ai-adapter-finder'),
                'no_results' => __('No matching adapters found. Please try different answers.', 'ai-adapter-finder')
            )
        ));
    }
}

/**
 * AI Adapter Quiz Widget for Elementor
 */
class AI_Adapter_Quiz_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'ai_adapter_quiz';
    }
    
    public function get_title() {
        return __('AI Adapter Quiz', 'ai-adapter-finder');
    }
    
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    
    public function get_categories() {
        return array('ai-adapter-finder');
    }
    
    public function get_script_depends() {
        return array('ai-adapter-elementor-widgets');
    }
    
    public function get_style_depends() {
        return array('ai-adapter-elementor-widgets');
    }
    
    protected function register_controls() {
        
        // Content Section
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Quiz Settings', 'ai-adapter-finder'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );
        
        $this->add_control(
            'quiz_type',
            array(
                'label' => __('Quiz Type', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'akinator',
                'options' => array(
                    'akinator' => __('Akinator Style (Yes/No Questions)', 'ai-adapter-finder'),
                    'comprehensive' => __('Comprehensive Quiz', 'ai-adapter-finder'),
                ),
            )
        );
        
        $this->add_control(
            'quiz_title',
            array(
                'label' => __('Quiz Title', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Find Your Perfect Adapter', 'ai-adapter-finder'),
                'placeholder' => __('Enter quiz title', 'ai-adapter-finder'),
            )
        );
        
        $this->add_control(
            'quiz_description',
            array(
                'label' => __('Quiz Description', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Answer a few quick questions and let our AI find the perfect adapter for your device.', 'ai-adapter-finder'),
                'placeholder' => __('Enter quiz description', 'ai-adapter-finder'),
            )
        );
        
        $this->add_control(
            'show_progress_bar',
            array(
                'label' => __('Show Progress Bar', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'ai-adapter-finder'),
                'label_off' => __('Hide', 'ai-adapter-finder'),
                'return_value' => 'yes',
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_confidence_score',
            array(
                'label' => __('Show Confidence Score', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'ai-adapter-finder'),
                'label_off' => __('Hide', 'ai-adapter-finder'),
                'return_value' => 'yes',
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'max_results',
            array(
                'label' => __('Maximum Results', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 20,
                'step' => 1,
                'default' => 5,
            )
        );
        
        $this->add_control(
            'enable_ai_explanations',
            array(
                'label' => __('Enable AI Explanations', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'ai-adapter-finder'),
                'label_off' => __('No', 'ai-adapter-finder'),
                'return_value' => 'yes',
                'default' => 'yes',
                'description' => __('Show AI-generated explanations for recommendations', 'ai-adapter-finder'),
            )
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            array(
                'label' => __('Quiz Style', 'ai-adapter-finder'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );
        
        $this->add_control(
            'quiz_theme',
            array(
                'label' => __('Quiz Theme', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'modern',
                'options' => array(
                    'modern' => __('Modern', 'ai-adapter-finder'),
                    'classic' => __('Classic', 'ai-adapter-finder'),
                    'minimal' => __('Minimal', 'ai-adapter-finder'),
                    'akinator' => __('Akinator Style', 'ai-adapter-finder'),
                ),
            )
        );
        
        $this->add_control(
            'primary_color',
            array(
                'label' => __('Primary Color', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => array(
                    'type' => \Elementor\Core\Schemes\Color::get_type(),
                    'value' => \Elementor\Core\Schemes\Color::COLOR_1,
                ),
                'default' => '#007cba',
            )
        );
        
        $this->add_control(
            'secondary_color',
            array(
                'label' => __('Secondary Color', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => array(
                    'type' => \Elementor\Core\Schemes\Color::get_type(),
                    'value' => \Elementor\Core\Schemes\Color::COLOR_2,
                ),
                'default' => '#666666',
            )
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'question_typography',
                'label' => __('Question Typography', 'ai-adapter-finder'),
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .ai-quiz-question',
            )
        );
        
        $this->add_responsive_control(
            'quiz_padding',
            array(
                'label' => __('Quiz Padding', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array('px', '%', 'em'),
                'selectors' => array(
                    '{{WRAPPER}} .ai-adapter-quiz-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'quiz_border',
                'label' => __('Quiz Border', 'ai-adapter-finder'),
                'selector' => '{{WRAPPER}} .ai-adapter-quiz-container',
            )
        );
        
        $this->add_control(
            'quiz_border_radius',
            array(
                'label' => __('Border Radius', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array('px', '%'),
                'selectors' => array(
                    '{{WRAPPER}} .ai-adapter-quiz-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'quiz_box_shadow',
                'label' => __('Box Shadow', 'ai-adapter-finder'),
                'selector' => '{{WRAPPER}} .ai-adapter-quiz-container',
            )
        );
        
        $this->end_controls_section();
        
        // Button Style Section
        $this->start_controls_section(
            'button_style_section',
            array(
                'label' => __('Button Style', 'ai-adapter-finder'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'button_typography',
                'label' => __('Button Typography', 'ai-adapter-finder'),
                'scheme' => \Elementor\Core\Schemes\Typography::TYPOGRAPHY_4,
                'selector' => '{{WRAPPER}} .ai-quiz-button',
            )
        );
        
        $this->add_control(
            'button_text_color',
            array(
                'label' => __('Button Text Color', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => array(
                    '{{WRAPPER}} .ai-quiz-button' => 'color: {{VALUE}};',
                ),
            )
        );
        
        $this->add_control(
            'button_background_color',
            array(
                'label' => __('Button Background', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#007cba',
                'selectors' => array(
                    '{{WRAPPER}} .ai-quiz-button' => 'background-color: {{VALUE}};',
                ),
            )
        );
        
        $this->add_control(
            'button_hover_color',
            array(
                'label' => __('Button Hover Background', 'ai-adapter-finder'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#005a87',
                'selectors' => array(
                    '{{WRAPPER}} .ai-quiz-button:hover' => 'background-color: {{VALUE}};',
                ),
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $quiz_id = 'ai-quiz-' . $this->get_id();
        $quiz_data = array(
            'quiz_type' => $settings['quiz_type'],
            'max_results' => $settings['max_results'],
            'show_progress' => $settings['show_progress_bar'] === 'yes',
            'show_confidence' => $settings['show_confidence_score'] === 'yes',
            'enable_ai_explanations' => $settings['enable_ai_explanations'] === 'yes',
            'theme' => $settings['quiz_theme'],
            'colors' => array(
                'primary' => $settings['primary_color'],
                'secondary' => $settings['secondary_color']
            )
        );
        ?>
        <div class="ai-adapter-quiz-container" data-quiz-id="<?php echo esc_attr($quiz_id); ?>" data-quiz-settings="<?php echo esc_attr(json_encode($quiz_data)); ?>">
            
            <div class="ai-quiz-header">
                <h3 class="ai-quiz-title"><?php echo esc_html($settings['quiz_title']); ?></h3>
                <p class="ai-quiz-description"><?php echo esc_html($settings['quiz_description']); ?></p>
            </div>
            
            <?php if ($settings['show_progress_bar'] === 'yes') : ?>
            <div class="ai-quiz-progress-container" style="display: none;">
                <div class="ai-quiz-progress-bar">
                    <div class="ai-quiz-progress-fill" style="width: 0%;"></div>
                </div>
                <span class="ai-quiz-progress-text">0%</span>
            </div>
            <?php endif; ?>
            
            <?php if ($settings['show_confidence_score'] === 'yes') : ?>
            <div class="ai-quiz-confidence-container" style="display: none;">
                <div class="ai-quiz-confidence-meter">
                    <div class="ai-quiz-confidence-fill" style="width: 0%;"></div>
                </div>
                <span class="ai-quiz-confidence-text">Confidence: 0%</span>
            </div>
            <?php endif; ?>
            
            <div class="ai-quiz-content">
                <div class="ai-quiz-question-container">
                    <div class="ai-quiz-question-text"></div>
                    <div class="ai-quiz-options"></div>
                </div>
                
                <div class="ai-quiz-controls">
                    <button type="button" class="ai-quiz-button ai-quiz-start-btn"><?php _e('Start Quiz', 'ai-adapter-finder'); ?></button>
                    <button type="button" class="ai-quiz-button ai-quiz-next-btn" style="display: none;"><?php _e('Next Question', 'ai-adapter-finder'); ?></button>
                    <button type="button" class="ai-quiz-button ai-quiz-back-btn" style="display: none;"><?php _e('Previous', 'ai-adapter-finder'); ?></button>
                </div>
            </div>
            
            <div class="ai-quiz-results" style="display: none;">
                <h4><?php _e('Your AI Recommendations', 'ai-adapter-finder'); ?></h4>
                <div class="ai-quiz-results-content"></div>
                <button type="button" class="ai-quiz-button ai-quiz-restart-btn"><?php _e('Take Quiz Again', 'ai-adapter-finder'); ?></button>
            </div>
            
            <div class="ai-quiz-loading" style="display: none;">
                <div class="ai-quiz-spinner"></div>
                <p class="ai-quiz-loading-text"><?php _e('AI is analyzing your answers...', 'ai-adapter-finder'); ?></p>
            </div>
        </div>
        <?php
    }
    
    protected function content_template() {
        ?>
        <# 
        var quizId = 'ai-quiz-' + view.getID();
        var quizData = {
            quiz_type: settings.quiz_type,
            max_results: settings.max_results,
            show_progress: settings.show_progress_bar === 'yes',
            show_confidence: settings.show_confidence_score === 'yes',
            enable_ai_explanations: settings.enable_ai_explanations === 'yes',
            theme: settings.quiz_theme,
            colors: {
                primary: settings.primary_color,
                secondary: settings.secondary_color
            }
        };
        #>
        <div class="ai-adapter-quiz-container" data-quiz-id="{{{quizId}}}" data-quiz-settings="{{{JSON.stringify(quizData)}}}">
            
            <div class="ai-quiz-header">
                <h3 class="ai-quiz-title">{{{settings.quiz_title}}}</h3>
                <p class="ai-quiz-description">{{{settings.quiz_description}}}</p>
            </div>
            
            <# if (settings.show_progress_bar === 'yes') { #>
            <div class="ai-quiz-progress-container" style="display: none;">
                <div class="ai-quiz-progress-bar">
                    <div class="ai-quiz-progress-fill" style="width: 0%;"></div>
                </div>
                <span class="ai-quiz-progress-text">0%</span>
            </div>
            <# } #>
            
            <# if (settings.show_confidence_score === 'yes') { #>
            <div class="ai-quiz-confidence-container" style="display: none;">
                <div class="ai-quiz-confidence-meter">
                    <div class="ai-quiz-confidence-fill" style="width: 0%;"></div>
                </div>
                <span class="ai-quiz-confidence-text">Confidence: 0%</span>
            </div>
            <# } #>
            
            <div class="ai-quiz-content">
                <div class="ai-quiz-question-container">
                    <div class="ai-quiz-question-text"></div>
                    <div class="ai-quiz-options"></div>
                </div>
                
                <div class="ai-quiz-controls">
                    <button type="button" class="ai-quiz-button ai-quiz-start-btn">Start Quiz</button>
                    <button type="button" class="ai-quiz-button ai-quiz-next-btn" style="display: none;">Next Question</button>
                    <button type="button" class="ai-quiz-button ai-quiz-back-btn" style="display: none;">Previous</button>
                </div>
            </div>
            
            <div class="ai-quiz-results" style="display: none;">
                <h4>Your AI Recommendations</h4>
                <div class="ai-quiz-results-content"></div>
                <button type="button" class="ai-quiz-button ai-quiz-restart-btn">Take Quiz Again</button>
            </div>
            
            <div class="ai-quiz-loading" style="display: none;">
                <div class="ai-quiz-spinner"></div>
                <p class="ai-quiz-loading-text">AI is analyzing your answers...</p>
            </div>
        </div>
        <?php
    }
}

// Initialize the integration
AI_Adapter_Finder_Elementor_Integration::get_instance();
?>"""

# Save the Elementor integration
with open('class-elementor-integration.php', 'w') as f:
    f.write(elementor_integration)

print("✅ Elementor Widget integration created!")
print("📄 File: class-elementor-integration.php") 
print("🔧 Features:")
print("   • Custom AI Adapter Quiz widget")
print("   • Advanced Elementor controls and settings")
print("   • Multiple quiz themes and styling options") 
print("   • Progress bar and confidence meter")
print("   • Responsive design controls")
print("   • Typography and color customization")
print("   • AJAX integration for real-time interactions")
print("   • Both live and editor view templates")