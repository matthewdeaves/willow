# Create a sample product database CSV for the WordPress plugin
import csv

products_data = [
    {
        'title': 'MacBook Air USB-C Charger - 30W',
        'manufacturer': 'Apple',
        'port_type': 'usb-c',
        'form_factor': 'compact',
        'device_gender': 'universal',
        'device_cat': 'laptop',
        'device_compatibility': 'MacBook Air, iPad Pro, iPhone 15',
        'price': 59.00,
        'rating': 4.8,
        'certified': True,
        'status': 'approved',
        'rel_score': 0.95,
        'views': 1250,
        'created': '2024-08-15'
    },
    {
        'title': 'iPhone Lightning Cable + 20W Adapter',
        'manufacturer': 'Apple',
        'port_type': 'lightning',
        'form_factor': 'standard',
        'device_gender': 'universal',
        'device_cat': 'phone',
        'device_compatibility': 'iPhone 6-14, iPad with Lightning',
        'price': 39.00,
        'rating': 4.6,
        'certified': True,
        'status': 'approved',
        'rel_score': 0.92,
        'views': 2100,
        'created': '2024-07-20'
    },
    {
        'title': 'Samsung Galaxy USB-C Fast Charger - 45W',
        'manufacturer': 'Samsung',
        'port_type': 'usb-c',
        'form_factor': 'compact',
        'device_gender': 'universal',
        'device_cat': 'phone',
        'device_compatibility': 'Samsung Galaxy S20+, Google Pixel, Most Android phones',
        'price': 29.00,
        'rating': 4.4,
        'certified': True,
        'status': 'approved',
        'rel_score': 0.88,
        'views': 1850,
        'created': '2024-06-10'
    },
    {
        'title': 'Gaming Laptop Power Adapter - 180W',
        'manufacturer': 'ASUS',
        'port_type': 'barrel',
        'form_factor': 'large',
        'device_gender': 'universal',
        'device_cat': 'gaming_laptop',
        'device_compatibility': 'ASUS ROG Series, High-power gaming laptops',
        'price': 89.00,
        'rating': 4.7,
        'certified': True,
        'status': 'approved',
        'rel_score': 0.91,
        'views': 890,
        'created': '2024-05-25'
    },
    {
        'title': 'AirPods Pro USB-C Charging Case',
        'manufacturer': 'Apple',
        'port_type': 'usb-c',
        'form_factor': 'compact',
        'device_gender': 'universal',
        'device_cat': 'earbuds',
        'device_compatibility': 'AirPods Pro 2nd Gen, AirPods 3rd Gen with USB-C',
        'price': 79.00,
        'rating': 4.9,
        'certified': True,
        'status': 'approved',
        'rel_score': 0.96,
        'views': 3200,
        'created': '2024-09-01'
    },
    {
        'title': '6-Port USB Charging Hub - 60W',
        'manufacturer': 'Anker',
        'port_type': 'multiple',
        'form_factor': 'desktop',
        'device_gender': 'universal',
        'device_cat': 'charging_hub',
        'device_compatibility': 'Universal - supports all USB devices',
        'price': 45.00,
        'rating': 4.5,
        'certified': False,
        'status': 'approved',
        'rel_score': 0.83,
        'views': 1640,
        'created': '2024-04-12'
    },
    {
        'title': 'MacBook Pro MagSafe 2 - 85W',
        'manufacturer': 'Apple',
        'port_type': 'magsafe2',
        'form_factor': 'standard',
        'device_gender': 'universal',
        'device_cat': 'laptop',
        'device_compatibility': 'MacBook Pro 15-inch (2012-2015)',
        'price': 79.00,
        'rating': 4.3,
        'certified': True,
        'status': 'approved',
        'rel_score': 0.89,
        'views': 750,
        'created': '2024-03-18'
    },
    {
        'title': 'Wireless Phone Charger Pad - 15W',
        'manufacturer': 'Belkin',
        'port_type': 'wireless',
        'form_factor': 'pad',
        'device_gender': 'universal',
        'device_cat': 'phone',
        'device_compatibility': 'iPhone 8+, Samsung Galaxy, Qi-enabled devices',
        'price': 35.00,
        'rating': 4.2,
        'certified': True,
        'status': 'approved',
        'rel_score': 0.78,
        'views': 1120,
        'created': '2024-02-14'
    },
    {
        'title': 'Dell Laptop Adapter - 90W',
        'manufacturer': 'Dell',
        'port_type': 'barrel',
        'form_factor': 'standard',
        'device_gender': 'universal',
        'device_cat': 'laptop',
        'device_compatibility': 'Dell Inspiron, Latitude series',
        'price': 42.00,
        'rating': 4.1,
        'certified': True,
        'status': 'approved',
        'rel_score': 0.85,
        'views': 680,
        'created': '2024-01-30'
    },
    {
        'title': 'Portable Power Bank with USB-C - 20000mAh',
        'manufacturer': 'Anker',
        'port_type': 'usb-c',
        'form_factor': 'portable',
        'device_gender': 'universal',
        'device_cat': 'power_bank',
        'device_compatibility': 'Universal - phones, tablets, laptops',
        'price': 55.00,
        'rating': 4.6,
        'certified': False,
        'status': 'approved',
        'rel_score': 0.87,
        'views': 2890,
        'created': '2024-08-05'
    }
]

# Write to CSV
with open('adapter_products_database.csv', 'w', newline='', encoding='utf-8') as csvfile:
    fieldnames = ['title', 'manufacturer', 'port_type', 'form_factor', 'device_gender', 
                 'device_cat', 'device_compatibility', 'price', 'rating', 'certified', 
                 'status', 'rel_score', 'views', 'created']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    
    writer.writeheader()
    for product in products_data:
        writer.writerow(product)

print("✅ Product database CSV created!")
print("📊 Database contains:")
print(f"   • {len(products_data)} sample products")
print(f"   • {len(set(p['manufacturer'] for p in products_data))} manufacturers")
print(f"   • {len(set(p['port_type'] for p in products_data))} port types")
print(f"   • {len(set(p['device_cat'] for p in products_data))} device categories")
print("\n📄 File: adapter_products_database.csv")

# Create a summary of all generated files
print("\n" + "="*60)
print("🎯 COMPLETE AI ADAPTER FINDER SYSTEM GENERATED")
print("="*60)

files_summary = [
    {
        "file": "adapter_finder_quiz_structure.json",
        "description": "Comprehensive quiz structure with 8 adaptive questions",
        "size": "~3KB",
        "features": ["Multi-step form", "Conditional logic", "AI matching algorithm"]
    },
    {
        "file": "akinator_adapter_quiz.json", 
        "description": "Akinator-style binary decision tree quiz",
        "size": "~4KB",
        "features": ["Yes/No questions", "Binary elimination", "Confidence scoring"]
    },
    {
        "file": "ai-adapter-finder-pro.php",
        "description": "Main WordPress plugin file",
        "size": "~15KB", 
        "features": ["Plugin structure", "Database tables", "Admin interface", "AJAX handlers"]
    },
    {
        "file": "class-formidable-integration.php",
        "description": "Formidable Forms integration plugin",
        "size": "~12KB",
        "features": ["Custom field types", "Form actions", "Email results", "Real-time quiz"]
    },
    {
        "file": "class-elementor-integration.php",
        "description": "Elementor widget integration",
        "size": "~18KB",
        "features": ["Custom widgets", "Advanced controls", "Multiple themes", "Responsive design"]
    },
    {
        "file": "adapter_products_database.csv",
        "description": "Sample product database",
        "size": "~2KB",
        "features": ["10 sample products", "Multiple manufacturers", "Various categories"]
    },
    {
        "file": "AI Adapter Finder Web App",
        "description": "Full-featured web application demo", 
        "size": "Live demo",
        "features": ["Interactive quizzes", "AI recommendations", "Modern UI", "Mobile responsive"]
    }
]

for i, file_info in enumerate(files_summary, 1):
    print(f"\n{i}. {file_info['file']}")
    print(f"   📝 {file_info['description']}")
    print(f"   📏 Size: {file_info['size']}")
    print(f"   🔧 Features: {', '.join(file_info['features'])}")

print(f"\n📁 Total files generated: {len(files_summary)}")
print("✨ Complete development-ready plugin suite with working demo!")